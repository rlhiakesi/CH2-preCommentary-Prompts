SBL 1.0 resolved page rendering package
Render target: CH2-P009
Entry file: CH2-P009.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Manga Me Character Sheet.png
  Assets/Manga-Me-Commentary-Gestures/Manga-Me-Gesture-Refine.png
  Assets/Vortex-canonical-specification.txt
  Assets/Manga-Me-Commentary-Gestures/Manga-Me-Gesture-Explain.png
  Assets/Vortex-character-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
